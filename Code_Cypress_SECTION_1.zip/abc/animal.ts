import {add, sub} from './calculcator';


let result: number = sub(3, 5);
console.log(result);
