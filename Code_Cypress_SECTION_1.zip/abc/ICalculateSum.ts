export interface ICalculateSum {
    getTotal(): number;
}