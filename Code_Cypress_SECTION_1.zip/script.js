function showMessage () {
    alert("Hello Itlearn");
}
//showMessage();
let header = document.getElementById('main-header');
header.style.color = "red";
header.style.background = "blue";
header.innerHTML = "HTML Header change"